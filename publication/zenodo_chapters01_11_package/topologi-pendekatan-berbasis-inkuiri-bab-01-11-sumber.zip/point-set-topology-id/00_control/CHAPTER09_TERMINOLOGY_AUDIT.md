# O003/C90 Indonesian terminology audit before Chapter 10

Date: 2026-08-22 (Europe/Berlin)  
Scope: admitted Chapters 1-9 only; no Chapter 10 translation was started before this audit.

## arXiv gate

A bounded search of the official arXiv search service found no Indonesian-language
point-set/general-topology source under the exact field phrases most likely to occur
in an Indonesian source package:

- `"ruang metrik"`: https://arxiv.org/search/?query=%22ruang+metrik%22&searchtype=all
- `"ruang topologi"`: https://arxiv.org/search/?query=%22ruang+topologi%22&searchtype=all
- `"himpunan terbuka"`: https://arxiv.org/search/?query=%22himpunan+terbuka%22&searchtype=all

Each official result page returned no results on 2026-08-22. No Indonesian
topology TeX source package was therefore available from this bounded arXiv
search. The user-authorized PDF fallback was used; this is not represented as
arXiv or TeX evidence.

## Primary fallback witness

- Oki Neswan, *Dari Barisan Bilangan ke Barisan Fungsi*.
- FMIPA-ITB; Workshop Pembelajaran Matematika SNAMA 2019 at UPH,
  6 September 2019.
- Source URL:
  https://snama2019.kamindo.org/wp-content/uploads/sites/2/2018/02/seqoffunctions.pdf
- Durable local witness:
  `authority/terminology/oki-neswan-dari-barisan-bilangan-ke-barisan-fungsi-snama2019.pdf`
- Identity: 723,813 bytes; SHA-256
  `636b5110a6ac6fece61f75bb4a3c04206734b4806e5335df21c096b8cbe9fdee`.
- Form: a 47-frame Beamer teaching deck represented by 150 physical overlay
  pages. PDF metadata identifies LaTeX with the Beamer class and pdfTeX.

The actual PDF body, not search snippets, was extracted and visually checked.
Representative physical pages 39, 44, 54, 145, 146 and 149 show the field
forms `ruang topologi`, `ruang metrik`, `himpunan buka`, `himpunan tutup`,
`lingkungan`, `tutupan`, `kekonvergenan`, `kekontinuan`, `basis`, `subbasis`,
`topologi hasil kali`, and `topologi seragam`.

## Corroborating topology-course witness

- Universitas Terbuka, *Tinjauan Mata Kuliah: Pengantar Topologi* (PEMA4427).
- Source URL:
  https://pustaka.ut.ac.id/lib/wp-content/uploads/pdfmk/PEMA442702-TM.pdf
- Durable local witness:
  `authority/terminology/universitas-terbuka-pema4427-pengantar-topologi-overview.pdf`
- Identity: 96,422 bytes; SHA-256
  `3271d0016f0386079f53202021b0f717b1c87103d469edcb4a3c5f755474fcbc`.
- Form: three-page A5 course overview. Physical pages 1-2 were visually
  checked and use `ruang topologi`, `ruang metrik`, `basis`, `subbasis`,
  `himpunan tertutup`, `ruang kompak`, `selimut buka`, and
  `himpunan tak terhubung`.

## Decisions and propagation

1. **Changed `topological space` to `ruang topologi`.** Both independent
   teaching witnesses use this form. Eleven already translated occurrences in
   ten source files were changed from `ruang topologis`; glossary entry
   O003-T011 now records the evidence and retains the old form only as an
   intelligible non-house variant.
2. **Changed topological `closure` to `tutupan`.** The ITB witness explicitly
   defines an `operator tutupan`, and additional Indonesian institutional
   topology/analysis material uses the same mathematical noun. Eight
   topological occurrences in three Chapter 5 companion files were changed;
   the ordinary phrase `penutupan matematisnya` in Chapter 9 was deliberately
   left untouched. O003-T014 is now approved and distinguishes `tutupan` from
   `himpunan tertutup`.
3. **Retained the house forms** `himpunan terbuka`, `bola terbuka`,
   `konvergensi`, `konvergensi titik demi titik`, `subhimpunan`, and
   `kekontinuan`. The witnesses establish the aliases `himpunan buka`,
   `bola buka`, `kekonvergenan`, `konvergen per titik`, `himpunan bagian`,
   and `kontinuitas`, but do not make the edition's existing forms
   mathematically wrong. The glossary now records those aliases so future
   translation does not oscillate between them. Introductory `himpunan bagian`
   is permitted rather than mechanically rewritten.
4. **Removed proven internal drift.** Five standalone `kontinuitas` instances
   in the Chapter 8 companion became `kekontinuan` (the five genuine
   `diskontinuitas` forms were retained); six Chapter 9 instances of
   `ketaksamaan segitiga` became the approved `pertidaksamaan segitiga`; one
   Chapter 9 mathematical `elemen` became `unsur`; and two set-theoretic
   `perpotongan` instances became `irisan`. A geometric intersection in the
   Chapter 7 guide was correctly retained as `perpotongan`.
5. **Added future-facing controlled terms** for `konvergensi`,
   `himpunan tertutup`, `kekompakan`, `ruang kompak`, `topologi hasil kali`,
   `topologi seragam`, and `subbasis` as O003-T122 through O003-T128.

The exact model provenance required by the user is present in `repo/README.md`
and in the Chapter 9 Zenodo/Figshare release metadata as
`OpenAI Codex gpt-5.6-sol, Ultra`; source-author, institutional and human
credits remain intact.

## Gate result

Terminology audit: **pass with propagated refinements**. Rebuild and rerun the
cumulative Chapters 1-9 structural, backend, HTML, PDF and visual checks before
advancing the production cursor to Chapter 10. The pre-audit Chapter 9 public
bytes remain a valid historical release boundary; the corrected boundary must
be published as its next maintenance version after QA.
