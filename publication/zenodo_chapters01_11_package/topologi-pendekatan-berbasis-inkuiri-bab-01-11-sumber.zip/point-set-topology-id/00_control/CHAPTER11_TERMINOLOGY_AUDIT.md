# O003/C90 Indonesian terminology audit — Chapter 11 extension

Date: 2026-08-23 (Europe/Berlin)  
Scope: Chapter 11, *Subruang dan Hasil Kali Ruang Metrik*, before its first
cumulative build and publication boundary. This extends rather than replaces
`CHAPTER09_TERMINOLOGY_AUDIT.md`.

## arXiv source gate

A new bounded search of the official arXiv search service found zero results
for each exact Indonesian field phrase `ruang metrik`, `ruang topologi`,
`himpunan terbuka`, `subruang`, `topologi hasil kali`, `metrik hasil kali`,
`ruang Hilbert`, and `ruang bernorma`. The broader exact phrase `Bahasa
Indonesia` produced 17 records, but none was a point-set-topology source; the
four results for `Indonesia topology` were English and not representative
Indonesian point-set-topology prose. Consequently there was no qualifying
Indonesian arXiv TeX package to download or unpack. No source package is
claimed where none exists.

The controlling fallback remains the actual Indonesian PDF body already
inspected and frozen for Chapter 9:

- Oki Neswan, *Dari Barisan Bilangan ke Barisan Fungsi*, FMIPA-ITB/SNAMA
  2019, 723,813 bytes, SHA-256
  `636b5110a6ac6fece61f75bb4a3c04206734b4806e5335df21c096b8cbe9fdee`;
  local witness
  `authority/terminology/oki-neswan-dari-barisan-bilangan-ke-barisan-fungsi-snama2019.pdf`.
  Its extracted body contains `ruang topologi`, `ruang metrik`, `hasil kali`,
  `topologi hasil kali`, `tutupan`, and `kekontinuan`.
- Universitas Terbuka, *Tinjauan Mata Kuliah: Pengantar Topologi* PEMA4427,
  96,422 bytes, SHA-256
  `3271d0016f0386079f53202021b0f717b1c87103d469edcb4a3c5f755474fcbc`;
  local witness
  `authority/terminology/universitas-terbuka-pema4427-pengantar-topologi-overview.pdf`.

Both are PDF-only public surfaces. The first identifies LaTeX/Beamer
generation in its metadata, but no public editable source package was found.

## Chapter 11 corroborating primary witnesses

Two directly relevant Indonesian university-journal PDFs were downloaded from
their primary article sites and inspected in full-text form:

1. Badrulfalah, Khafsah Joebaedi, and Iin Irianingsih, *Sifat Sub Ruang
   Topologi Hasil Kali Ruang Metrik Kerucut*, *Euclid* 4(2), 2017,
   DOI `10.33603/e.v4i2.418`; primary PDF
   `https://jurnal.ugj.ac.id/index.php/Euclid/article/download/418/332`.
   The six-page local witness is 448,039 bytes, SHA-256
   `aa75607bde2d568e8e8c5a748ac34e043a5c1f2d95591e2f2de2a8c78787582b`,
   at
   `authority/terminology/badrulfalah-joebaedi-irianingsih-sub-ruang-topologi-hasil-kali-2017.pdf`.
   Text extraction finds `subruang` 20 times, the spaced title form `sub ruang`
   once, `ruang topologi` 17 times, `topologi hasil kali` 10 times, and `ruang
   metrik` 37 times.
2. Razis Aji Saputro, Susilo Hariyanto, and Y. D. Sumanto, *Operator Accretive
   Kuat pada Ruang Hilbert*, *Journal of Fundamental Mathematics and
   Applications* 1(1), 2018, DOI `10.14710/jfma.v1i1.10`; primary PDF
   `https://ejournal2.undip.ac.id/index.php/jfma/article/download/7386/7045`.
   The four-page local witness is 209,460 bytes, SHA-256
   `a8d61c1c9e090a9cad5294aa8f01733fbcb22d7495f2096f6b55e84cf523539d`,
   at
   `authority/terminology/saputro-hariyanto-sumanto-operator-accretive-ruang-hilbert-2018.pdf`.
   Text extraction finds `ruang Hilbert` 12 times, `norma` twice, `ruang
   bernorma` once, `ruang metrik` twice, and `kekontinuan` once.

These two records are corroboration, not substituted source material for the
edition, and no expression from them is imported.

## Decisions and propagation

- Retain the already approved `subruang`, `ruang topologi`, `ruang metrik`,
  `topologi hasil kali`, `ruang Hilbert`, `norma`, and `kekontinuan`. The solid
  form `subruang` is strongly preferred over the isolated spaced title form.
- Retain `hasil kali` rather than the avoidable loanword `produk`. The primary
  topology witnesses directly attest `topologi hasil kali`; `metrik hasil
  kali` is an internally consistent compositional choice, not falsely claimed
  as a directly attested phrase.
- Retain `ruang metrik hasil kali`, `ruang koordinat`, `ruang faktor`, `barisan
  tak menurun`, `pembenaman`, and `tertanam` under O003-T134 through O003-T141.
  No inspected evidence contradicts their mathematical meaning.
- Before the admitted build, five companion occurrences of `ketaksamaan` were
  normalized to the established `pertidaksamaan`, and eight reader-visible
  uses of `produk` were recast naturally with `hasil kali`. A bounded scan of
  the Chapter 11 source and companion then found no active controlled-term
  drift. Uses of `penutupan` for closing a proof or closure under an algebraic
  operation were deliberately not rewritten as topological `tutupan`.

The active cumulative reader wrapper and `README.md` carry the exact model
provenance `OpenAI Codex gpt-5.6-sol, Ultra` while retaining Steven Schlicker,
Grand Valley State University, source, and human-contributor credits and the
non-endorsement statement. Chapter 11 publication metadata must repeat that
same bounded provenance note at release.

## Gate result

**Pass with propagated refinements.** The search outcome, exact fallback
witnesses, terminology decisions, and model provenance are durable. Chapter
11 may proceed to rebuilt companion/backend QA and cumulative reader builds.
